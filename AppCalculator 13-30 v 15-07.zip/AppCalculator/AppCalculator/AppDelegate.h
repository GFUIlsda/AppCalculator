//
//  AppDelegate.h
//  AppCalculator
//
//  Created by SkyLORD on 11.07.13.
//  Copyright (c) 2013 MacBook Air. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
